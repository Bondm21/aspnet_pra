using DataAccess.Entities;

namespace DataAccess.MockDb;

public static partial class MockDb
{
    public static Dictionary<int, PlayEntity> Plays = new Dictionary<int, PlayEntity>()
    {

    };
}